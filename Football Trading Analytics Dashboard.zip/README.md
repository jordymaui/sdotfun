
  # Football Trading Analytics Dashboard

  This is a code bundle for Football Trading Analytics Dashboard. The original project is available at https://www.figma.com/design/e4SVxxjr6q10KRQfc7Adkm/Football-Trading-Analytics-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  