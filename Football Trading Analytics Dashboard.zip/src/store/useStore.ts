import { create } from 'zustand';

export interface Position {
  player: string;
  tag: 'Keep' | 'Watch' | 'Sell';
  batch: 'Batch 1' | 'Batch 2';
  shares: number;
  avgCost: number;
  price: number;
  currentValue?: number;
  realisedPnL?: number;
  unrealisedPnL?: number;
  roi?: number;
}

export interface Trade {
  ts: string;
  player: string;
  side: 'buy' | 'sell';
  shares: number;
  price: number;
  note?: string;
}

export interface Snapshot {
  date: string;
  portfolioValueUSD: number;
  cashUSD: number;
  realisedUSD: number;
  unrealisedUSD: number;
  depositsUSD: number;
  withdrawalsUSD: number;
}

export interface Settings {
  initialDepositsUSD: number;
  sideLiquidityUSD: number;
  withdrawTargetUSD: number;
}

export interface StoreState {
  settings: Settings;
  positions: Position[];
  trades: Trade[];
  snapshots: Snapshot[];
  cashUSD: number;
  
  // Filters
  batchFilter: 'All' | 'Batch 1' | 'Batch 2';
  tagFilter: 'All' | 'Keep' | 'Watch' | 'Sell';
  
  // Computed totals
  totalPortfolioValue: number;
  totalUnrealisedPnL: number;
  totalRealisedPnL: number;
  totalROI: number;
  totalCostBasis: number;
  
  // Actions
  updateFromJSON: (data: Partial<StoreState>) => void;
  addTrade: (trade: Trade) => void;
  recalculateAll: () => void;
  setBatchFilter: (filter: 'All' | 'Batch 1' | 'Batch 2') => void;
  setTagFilter: (filter: 'All' | 'Keep' | 'Watch' | 'Sell') => void;
  updatePositionBatch: (player: string, batch: 'Batch 1' | 'Batch 2') => void;
  getFilteredPositions: () => Position[];
}

export const useStore = create<StoreState>((set, get) => ({
  settings: {
    initialDepositsUSD: 560,
    sideLiquidityUSD: 200,
    withdrawTargetUSD: 500,
  },
  positions: [],
  trades: [],
  snapshots: [],
  cashUSD: 0,
  batchFilter: 'All',
  tagFilter: 'All',
  totalPortfolioValue: 0,
  totalUnrealisedPnL: 0,
  totalRealisedPnL: 0,
  totalROI: 0,
  totalCostBasis: 0,

  updateFromJSON: (data) => {
    // Apply safe defaults for batch field
    const positions = (data.positions || get().positions).map(pos => ({
      ...pos,
      batch: pos.batch || 'Batch 2' as 'Batch 1' | 'Batch 2',
    }));
    
    set({
      settings: data.settings || get().settings,
      positions,
      trades: data.trades || get().trades,
      snapshots: data.snapshots || get().snapshots,
      batchFilter: data.batchFilter || get().batchFilter,
      tagFilter: data.tagFilter || get().tagFilter,
    });
    get().recalculateAll();
  },

  addTrade: (trade) => {
    const state = get();
    const existingPos = state.positions.find(p => p.player === trade.player);
    
    let newPositions = [...state.positions];
    
    if (trade.side === 'buy') {
      if (existingPos) {
        // Weighted average cost calculation
        const totalShares = existingPos.shares + trade.shares;
        const totalCost = (existingPos.shares * existingPos.avgCost) + (trade.shares * trade.price);
        const newAvgCost = totalShares > 0 ? totalCost / totalShares : existingPos.avgCost;
        
        newPositions = newPositions.map(p =>
          p.player === trade.player
            ? { ...p, shares: totalShares, avgCost: newAvgCost }
            : p
        );
      } else {
        newPositions.push({
          player: trade.player,
          tag: 'Watch',
          batch: 'Batch 2',
          shares: trade.shares,
          avgCost: trade.price,
          price: trade.price,
        });
      }
    } else if (trade.side === 'sell' && existingPos) {
      const newShares = Math.max(0, existingPos.shares - trade.shares);
      const realisedPnL = (trade.price - existingPos.avgCost) * Math.min(trade.shares, existingPos.shares);
      
      newPositions = newPositions.map(p =>
        p.player === trade.player
          ? { 
              ...p, 
              shares: newShares,
              realisedPnL: (p.realisedPnL || 0) + realisedPnL,
            }
          : p
      );
    }
    
    set({
      positions: newPositions,
      trades: [...state.trades, trade],
    });
    
    get().recalculateAll();
  },

  recalculateAll: () => {
    const state = get();
    const filteredPositions = get().getFilteredPositions();
    
    let totalCostBasis = 0;
    let totalCurrentValue = 0;
    let totalUnrealisedPnL = 0;
    let totalRealisedPnL = 0;

    const updatedPositions = state.positions.map(pos => {
      const currentValue = pos.shares * pos.price;
      const costBasis = pos.shares * pos.avgCost;
      const unrealisedPnL = currentValue - costBasis;
      const realisedPnL = pos.realisedPnL || 0;
      const totalPnL = unrealisedPnL + realisedPnL;
      const roi = costBasis > 0 ? (totalPnL / costBasis) * 100 : 0;

      return {
        ...pos,
        currentValue,
        unrealisedPnL,
        roi,
      };
    });

    // Calculate totals based on filtered positions
    filteredPositions.forEach(pos => {
      const currentValue = pos.shares * pos.price;
      const costBasis = pos.shares * pos.avgCost;
      const unrealisedPnL = currentValue - costBasis;
      const realisedPnL = pos.realisedPnL || 0;

      totalCostBasis += costBasis;
      totalCurrentValue += currentValue;
      totalUnrealisedPnL += unrealisedPnL;
      totalRealisedPnL += realisedPnL;
    });

    const totalROI = totalCostBasis > 0 ? ((totalUnrealisedPnL + totalRealisedPnL) / totalCostBasis) * 100 : 0;

    set({
      positions: updatedPositions,
      totalPortfolioValue: totalCurrentValue,
      totalUnrealisedPnL,
      totalRealisedPnL,
      totalROI,
      totalCostBasis,
    });
  },

  setBatchFilter: (filter) => {
    set({ batchFilter: filter });
    get().recalculateAll();
  },

  setTagFilter: (filter) => {
    set({ tagFilter: filter });
    get().recalculateAll();
  },

  updatePositionBatch: (player, batch) => {
    const state = get();
    const updatedPositions = state.positions.map(p =>
      p.player === player ? { ...p, batch } : p
    );
    set({ positions: updatedPositions });
    get().recalculateAll();
  },

  getFilteredPositions: () => {
    const state = get();
    return state.positions.filter(pos => {
      const batchMatch = state.batchFilter === 'All' || pos.batch === state.batchFilter;
      const tagMatch = state.tagFilter === 'All' || pos.tag === state.tagFilter;
      return batchMatch && tagMatch;
    });
  },
}));
