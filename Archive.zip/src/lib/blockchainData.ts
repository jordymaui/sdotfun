/**
 * Simple Blockchain Data Fetching
 * 
 * Fetches portfolio data directly from BaseScan API and Dune Analytics
 * No Web3/login complexity - just API calls with your wallet address
 */

// Your wallet address
export const WALLET_ADDRESS = '0xFc1A8921eA05bEC9ceb536f8aEE02AF881D72F6B';

// BaseScan API
const BASESCAN_API_BASE = 'https://api.basescan.org/api';
const BASESCAN_API_KEY = import.meta.env.VITE_BASESCAN_API_KEY || '';

// Dune API (optional - if you have API key)
const DUNE_API_BASE = 'https://api.dune.com/api/v1';

// ============================================
// TYPES
// ============================================

export interface TokenBalance {
  contractAddress: string;
  tokenName: string;
  tokenSymbol: string;
  balance: string;
  decimals: number;
  balanceFormatted: number;
}

export interface Transaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  tokenSymbol?: string;
  method?: string;
}

export interface PortfolioHolding {
  playerName: string;
  contractAddress: string;
  shares: number;
  tokenId?: string; // For ERC-1155
}

// ============================================
// BASESCAN API FUNCTIONS
// ============================================

/**
 * Fetch all token balances for your wallet from BaseScan
 */
export async function fetchTokenBalances(walletAddress: string = WALLET_ADDRESS): Promise<TokenBalance[]> {
  try {
    // BaseScan API endpoint for token balances
    const apiKeyParam = BASESCAN_API_KEY ? `&apikey=${BASESCAN_API_KEY}` : '';
    const url = `${BASESCAN_API_BASE}?module=account&action=tokentx&address=${walletAddress}&startblock=0&endblock=99999999&sort=asc${apiKeyParam}`;
    
    // Alternative: Use tokenlist API or custom endpoint
    // For now, we'll fetch transactions and extract unique tokens
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`BaseScan API error: ${response.statusText}`);
    }

    const data = await response.json();
    
    if (data.status !== '1' || !data.result) {
      console.warn('No token transactions found or API error');
      return [];
    }

    // Extract unique tokens from transactions
    const tokenMap = new Map<string, TokenBalance>();
    
    for (const tx of data.result) {
      const tokenAddress = tx.contractAddress;
      if (!tokenMap.has(tokenAddress)) {
        tokenMap.set(tokenAddress, {
          contractAddress: tokenAddress,
          tokenName: tx.tokenName || 'Unknown',
          tokenSymbol: tx.tokenSymbol || 'UNKNOWN',
          balance: '0', // BaseScan doesn't give current balance in this endpoint
          decimals: parseInt(tx.tokenDecimal) || 18,
          balanceFormatted: 0,
        });
      }
    }

    // Now fetch actual balances for each token
    const balances: TokenBalance[] = [];
    for (const [address, token] of tokenMap) {
      try {
        const balanceUrl = `${BASESCAN_API_BASE}?module=account&action=tokenbalance&contractaddress=${address}&address=${walletAddress}&tag=latest${apiKeyParam}`;
        const balanceResponse = await fetch(balanceUrl);
        const balanceData = await balanceResponse.json();
        
        if (balanceData.status === '1') {
          const balance = BigInt(balanceData.result);
          const divisor = BigInt(10 ** token.decimals);
          const formatted = Number(balance) / Number(divisor);
          
          if (formatted > 0) {
            balances.push({
              ...token,
              balance: balanceData.result,
              balanceFormatted: formatted,
            });
          }
        }
      } catch (error) {
        console.warn(`Failed to fetch balance for ${token.tokenSymbol}:`, error);
      }
    }

    return balances;
  } catch (error) {
    console.error('Error fetching token balances:', error);
    return [];
  }
}

/**
 * Fetch all transactions for your wallet
 */
export async function fetchTransactions(
  walletAddress: string = WALLET_ADDRESS,
  limit: number = 1000
): Promise<Transaction[]> {
  try {
    const apiKeyParam = BASESCAN_API_KEY ? `&apikey=${BASESCAN_API_KEY}` : '';
    const url = `${BASESCAN_API_BASE}?module=account&action=txlist&address=${walletAddress}&startblock=0&endblock=99999999&sort=desc${apiKeyParam}`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`BaseScan API error: ${response.statusText}`);
    }

    const data = await response.json();
    
    if (data.status !== '1' || !data.result) {
      return [];
    }

    return data.result.slice(0, limit).map((tx: any) => ({
      hash: tx.hash,
      from: tx.from,
      to: tx.to,
      value: tx.value,
      timestamp: parseInt(tx.timeStamp),
      method: tx.methodId || undefined,
    }));
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return [];
  }
}

/**
 * Fetch ERC-1155 token balances (for player shares)
 * BaseScan might not support this directly, so we'll need contract calls or Dune
 */
export async function fetchERC1155Balances(
  contractAddress: string,
  walletAddress: string = WALLET_ADDRESS
): Promise<PortfolioHolding[]> {
  // This requires calling the contract directly
  // We'll need the contract ABI and address
  // For now, return empty - will implement with contract address
  return [];
}

// ============================================
// DUNE ANALYTICS FUNCTIONS
// ============================================

/**
 * Fetch data from Dune Analytics query
 * 
 * You can create queries on Dune that aggregate Sport.Fun data
 * Then use the query ID here
 */
export async function fetchFromDune(
  queryId: string,
  apiKey?: string
): Promise<any> {
  if (!apiKey) {
    console.warn('Dune API key not provided');
    return null;
  }

  try {
    // Execute query
    const executeResponse = await fetch(`${DUNE_API_BASE}/query/${queryId}/execute`, {
      method: 'POST',
      headers: {
        'X-Dune-API-Key': apiKey,
        'Content-Type': 'application/json',
      },
    });

    const executeData = await executeResponse.json();
    const executionId = executeData.execution_id;

    if (!executionId) {
      throw new Error('Failed to execute Dune query');
    }

    // Poll for results
    let results = null;
    let attempts = 0;
    while (!results && attempts < 30) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const statusResponse = await fetch(`${DUNE_API_BASE}/execution/${executionId}/status`, {
        headers: {
          'X-Dune-API-Key': apiKey,
        },
      });

      const statusData = await statusResponse.json();
      
      if (statusData.state === 'QUERY_STATE_COMPLETED') {
        const resultsResponse = await fetch(`${DUNE_API_BASE}/execution/${executionId}/results`, {
          headers: {
            'X-Dune-API-Key': apiKey,
          },
        });
        results = await resultsResponse.json();
        break;
      }
      
      attempts++;
    }

    return results;
  } catch (error) {
    console.error('Error fetching from Dune:', error);
    return null;
  }
}

/**
 * Fetch Sport.Fun portfolio from Dune
 * 
 * Create a Dune query that filters by your wallet address
 * Then use the query ID here
 */
export async function fetchSportFunPortfolioFromDune(
  walletAddress: string = WALLET_ADDRESS,
  duneApiKey?: string,
  queryId?: string
): Promise<any> {
  if (!queryId || !duneApiKey) {
    console.warn('Dune query ID or API key not provided');
    return null;
  }

  const results = await fetchFromDune(queryId, duneApiKey);
  
  if (!results || !results.result) {
    return null;
  }

  // Filter results for your wallet address
  const walletData = results.result.rows.filter((row: any) => 
    row.wallet_address?.toLowerCase() === walletAddress.toLowerCase()
  );

  return walletData;
}

// ============================================
// SIMPLE PORTFOLIO FETCHER
// ============================================

/**
 * Simple function to fetch your portfolio
 * 
 * This is the main function you'll call
 * It tries multiple methods to get your data
 */
export async function fetchMyPortfolio(walletAddress: string = WALLET_ADDRESS) {
  console.log(`🔍 Fetching portfolio for ${walletAddress}...`);

  try {
    // Method 1: Fetch token balances from BaseScan
    const tokenBalances = await fetchTokenBalances(walletAddress);
    console.log(`✅ Found ${tokenBalances.length} tokens`);

    // Method 2: Fetch transactions
    const transactions = await fetchTransactions(walletAddress, 100);
    console.log(`✅ Found ${transactions.length} transactions`);

    // Method 3: Try Dune (if configured)
    const duneApiKey = import.meta.env.VITE_DUNE_API_KEY;
    const duneQueryId = import.meta.env.VITE_DUNE_QUERY_ID;
    
    let duneData = null;
    if (duneApiKey && duneQueryId) {
      duneData = await fetchSportFunPortfolioFromDune(walletAddress, duneApiKey, duneQueryId);
      if (duneData) {
        console.log(`✅ Found Dune data`);
      }
    }

    return {
      walletAddress,
      tokenBalances,
      transactions,
      duneData,
      fetchedAt: new Date().toISOString(),
    };
  } catch (error) {
    console.error('Error fetching portfolio:', error);
    throw error;
  }
}

