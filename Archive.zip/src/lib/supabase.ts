import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  'https://kwwcpxjnvudseryreptg.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt3d2NweGpudnVkc2VyeXJlcHRnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI5NDc5MDMsImV4cCI6MjA3ODUyMzkwM30.DREsKeUmCuh4c0lJdjdvhjMqDHYNt2-hyV9_-B99o7k'
);

console.log("✅ Connected to Supabase: NFL Portfolio Dashboard Live");

// Type definitions for Supabase views
export interface PortfolioSnapshot {
  display_name: string;
  shares: number;
  price_usd: number;
  value_usd: number;
  avg_cost: number;
  unrealised_pnl: number;
  label: 'KEEP' | 'WATCH' | 'SELL';
  release_batch: number;
  pack_batch: number;
}

export interface PortfolioTotals {
  holdings_value: number;
  net_cash: number;
  unrealised_pnl: number;
  realised_pnl: number;
  total_deposited: number;
  total_fees: number;
}

// Fetch portfolio snapshot (all players)
export async function fetchPortfolioSnapshot(): Promise<PortfolioSnapshot[]> {
  const { data, error } = await supabase
    .from('v_portfolio_snapshot')
    .select('*')
    .order('value_usd', { ascending: false });

  if (error) {
    console.error('Error fetching portfolio snapshot:', error);
    return [];
  }

  console.log('📊 Fetched portfolio snapshot:', data?.length || 0, 'players');
  return data || [];
}

// Fetch portfolio totals
export async function fetchPortfolioTotals(): Promise<PortfolioTotals | null> {
  const { data, error } = await supabase
    .from('v_portfolio_totals')
    .select('*')
    .single();

  if (error) {
    console.error('Error fetching portfolio totals:', error);
    return null;
  }

  console.log('💰 Fetched portfolio totals:', data);
  return data;
}