/**
 * Sync Blockchain Data to Supabase
 * 
 * Takes data from BaseScan/Dune and syncs it to your Supabase database
 */

import { supabase } from './supabase';

export interface PortfolioData {
  walletAddress: string;
  tokenBalances: any[];
  transactions: any[];
  duneData: any;
  fetchedAt: string;
}

/**
 * Sync portfolio data to Supabase
 */
export async function syncDataToSupabase(data: PortfolioData): Promise<void> {
  console.log('🔄 Syncing data to Supabase...');

  try {
    // 1. Process token balances (player shares)
    if (data.tokenBalances && data.tokenBalances.length > 0) {
      await syncTokenBalances(data.tokenBalances, data.walletAddress);
    }

    // 2. Process transactions (trades)
    if (data.transactions && data.transactions.length > 0) {
      await syncTransactions(data.transactions, data.walletAddress);
    }

    // 3. Process Dune data (if available)
    if (data.duneData && data.duneData.length > 0) {
      await syncDuneData(data.duneData, data.walletAddress);
    }

    // 4. Create daily snapshot
    await supabase.rpc('create_daily_snapshot');

    console.log('✅ Data synced to Supabase!');
  } catch (error) {
    console.error('❌ Error syncing to Supabase:', error);
    throw error;
  }
}

/**
 * Sync token balances to portfolio_holdings
 */
async function syncTokenBalances(balances: any[], walletAddress: string): Promise<void> {
  for (const balance of balances) {
    try {
      // Check if this is a Sport.Fun player token
      // You'll need to identify which tokens are players
      // For now, we'll sync all non-zero balances

      if (balance.balanceFormatted <= 0) continue;

      // Try to get player name from token symbol or contract
      // This might need mapping based on Sport.Fun's token structure
      const playerName = extractPlayerName(balance);

      if (!playerName) {
        console.warn(`Could not identify player for token ${balance.tokenSymbol}`);
        continue;
      }

      // Get or create player
      let { data: playerData, error: playerError } = await supabase
        .from('players')
        .select('id')
        .eq('display_name', playerName)
        .single();

      if (playerError && playerError.code === 'PGRST116') {
        // Create player if doesn't exist
        const { data: newPlayer, error: createError } = await supabase
          .from('players')
          .insert({
            display_name: playerName,
            game_type: 'NFL', // Default, adjust as needed
            pack_batch: 1,
            release_batch: 1,
          })
          .select('id')
          .single();

        if (createError) {
          console.error(`Error creating player ${playerName}:`, createError);
          continue;
        }
        playerData = newPlayer;
      } else if (playerError) {
        console.error(`Error fetching player ${playerName}:`, playerError);
        continue;
      }

      // Upsert holding
      const { error: holdingError } = await supabase
        .from('portfolio_holdings')
        .upsert({
          player_id: playerData.id,
          shares: balance.balanceFormatted,
          avg_cost: 0, // Will be calculated from transactions
        }, {
          onConflict: 'player_id',
        });

      if (holdingError) {
        console.error(`Error syncing holding for ${playerName}:`, holdingError);
      }
    } catch (error) {
      console.error('Error processing token balance:', error);
    }
  }
}

/**
 * Sync transactions to trades table
 */
async function syncTransactions(transactions: any[], walletAddress: string): Promise<void> {
  for (const tx of transactions) {
    try {
      // Filter for Sport.Fun related transactions
      // This depends on Sport.Fun's contract addresses
      // For now, we'll process all token transfers

      if (tx.value === '0' || !tx.to) continue;

      // Try to identify if this is a buy/sell
      // This requires knowing Sport.Fun's contract addresses
      const action = determineTradeAction(tx, walletAddress);

      if (!action) continue;

      // Extract player and trade details
      const tradeData = extractTradeData(tx);

      if (!tradeData) continue;

      // Record trade
      const { error } = await supabase.rpc('record_trade', {
        p_player_name: tradeData.playerName,
        p_action: action,
        p_shares: tradeData.shares,
        p_price: tradeData.price,
        p_fees: tradeData.fees || 0,
        p_notes: `Tx: ${tx.hash}`,
        p_trade_date: new Date(tx.timestamp * 1000).toISOString().split('T')[0],
      });

      if (error) {
        console.error(`Error recording trade:`, error);
      }
    } catch (error) {
      console.error('Error processing transaction:', error);
    }
  }
}

/**
 * Sync Dune data (if available)
 */
async function syncDuneData(duneData: any[], walletAddress: string): Promise<void> {
  // Dune data structure depends on your query
  // Process based on your specific Dune query results
  console.log('Processing Dune data:', duneData.length, 'rows');
  
  // Example: If Dune returns player holdings
  for (const row of duneData) {
    // Process each row based on your Dune query structure
    // This is custom to your Dune query
  }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Extract player name from token data
 * This needs to be customized based on Sport.Fun's token structure
 */
function extractPlayerName(balance: any): string | null {
  // Option 1: Token symbol contains player name
  if (balance.tokenSymbol && balance.tokenSymbol.length > 2) {
    return balance.tokenSymbol;
  }

  // Option 2: Token name contains player name
  if (balance.tokenName && balance.tokenName.length > 2) {
    return balance.tokenName;
  }

  // Option 3: Map contract address to player
  // You'll need to create a mapping of Sport.Fun contract addresses to players
  const contractToPlayer: Record<string, string> = {
    // Add Sport.Fun contract addresses here
    // '0x...': 'P.Mahomes',
  };

  if (contractToPlayer[balance.contractAddress]) {
    return contractToPlayer[balance.contractAddress];
  }

  return null;
}

/**
 * Determine if transaction is a buy or sell
 */
function determineTradeAction(tx: any, walletAddress: string): 'Buy' | 'Sell' | null {
  const walletLower = walletAddress.toLowerCase();
  
  // If you're sending tokens, it's a sell
  if (tx.from?.toLowerCase() === walletLower) {
    return 'Sell';
  }
  
  // If you're receiving tokens, it's a buy
  if (tx.to?.toLowerCase() === walletLower) {
    return 'Buy';
  }

  return null;
}

/**
 * Extract trade data from transaction
 */
function extractTradeData(tx: any): { playerName: string; shares: number; price: number; fees: number } | null {
  // This needs to be customized based on Sport.Fun's transaction structure
  // For now, return null - you'll need to parse the transaction data
  
  // Example parsing (adjust based on actual structure):
  // - Parse transaction input data
  // - Extract player ID/token ID
  // - Extract shares amount
  // - Extract price
  
  return null;
}
