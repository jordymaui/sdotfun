import { create } from 'zustand';
import { fetchPortfolioSnapshot, fetchPortfolioTotals, PortfolioSnapshot, PortfolioTotals } from '../lib/supabase';

export interface Player {
  name: string;
  pack_batch: number;
  release_batch: number;
  shares_owned: number;
  avg_cost: number;
  latest_price: number;
  status_tag: 'Keep' | 'Sell' | 'Watch';
  notes: string;
}

export interface PlayerDerived extends Player {
  is_owned: boolean;
  unrealised_value: number;
  avg_cost_value: number;
  unrealised_pnl: number;
}

export interface Trade {
  date: string;
  player: string;
  action: 'Buy' | 'Sell';
  shares: number;
  price: number;
  fees: number;
  notes: string;
  gross?: number;
  net?: number;
  realised_pnl?: number;
}

export interface PortfolioSettings {
  base_currency: string;
  deposit_total: number;
  withdrawn_total: number;
  cash_balance: number;
  fees_paid: number;
}

export interface PortfolioState {
  players: Player[];
  trades: Trade[];
  settings: PortfolioSettings;
  
  // Supabase live data
  isLoading: boolean;
  lastRefreshed: Date | null;
  
  // Filters
  showOnlyOwned: boolean;
  releaseBatchFilter: 'All' | 1 | 2 | 3;
  statusFilter: 'All' | 'Keep' | 'Sell' | 'Watch';
  searchQuery: string;
  hideZeroShares: boolean;
  
  // Actions
  setShowOnlyOwned: (value: boolean) => void;
  setReleaseBatchFilter: (value: 'All' | 1 | 2 | 3) => void;
  setStatusFilter: (value: 'All' | 'Keep' | 'Sell' | 'Watch') => void;
  setSearchQuery: (value: string) => void;
  setHideZeroShares: (value: boolean) => void;
  
  // Supabase actions
  refreshFromSupabase: () => Promise<void>;
  
  addTrade: (trade: Omit<Trade, 'gross' | 'net' | 'realised_pnl'>) => void;
  updatePlayer: (name: string, updates: Partial<Player>) => void;
  importPlayers: (csvData: string) => void;
  resetShares: () => void;
  updateSettings: (settings: Partial<PortfolioSettings>) => void;
  
  getFilteredPlayers: () => PlayerDerived[];
  getOwnedPlayers: () => PlayerDerived[];
  getTotalUnrealisedValue: () => number;
  getTotalUnrealisedPnL: () => number;
  getTotalRealisedPnL: () => number;
  getTotalPortfolioValue: () => number;
}

const INITIAL_PLAYERS_CSV = `name,pack_batch,release_batch,shares_owned,avg_cost,latest_price,status_tag,notes
P.Mahomes,1,3,3000,0.1262,0.0936,Keep,3000 shares - VWAP $0.1262
J.Jefferson,1,1,2500,0.0125,0.0542,Keep,Top WR - Batch 1
A.St. Brown,1,1,1000,0.0652,0.0551,Keep,Consistent performer
C.Lamb,1,1,2200,0.0125,0.0142,Keep,Elite target share
T.Hill,1,1,2000,0.0125,0.0140,Keep,Speed kills
D.Adams,1,1,1500,0.0125,0.0132,Watch,Veteran presence
S.Diggs,1,1,1200,0.0125,0.0128,Watch,Solid WR2
C.Olave,1,1,1500,0.0125,0.0135,Keep,High upside
L.McConkey,1,1,1500,0.0125,0.0130,Keep,Rookie promise
D.Moore,1,1,1000,0.0125,0.0127,Watch,Consistency concerns
G.Wilson,1,1,800,0.0125,0.0126,Watch,Situational value
T.Kelce,1,1,2000,0.0268,0.0221,Keep,Value buy - brand gravity + media tailwind
H.Henry,1,1,1000,0.0125,0.0129,Watch,Red zone threat
J.Jacobs,1,1,1000,0.0125,0.0128,Watch,RB1 usage
K.Walker,1,1,1500,0.0125,0.0133,Keep,Explosive RB
J.Cook,1,1,1500,0.0125,0.0131,Keep,High volume
S.Barkley,1,1,1800,0.0125,0.0139,Keep,Elite RB talent
B.Robinson,1,1,1000,0.0654,0.0565,Watch,Breakout candidate
C.McCaffrey,1,1,2000,0.0125,0.0143,Keep,CMC value
B.Mayfield,1,1,1000,0.0125,0.0128,Watch,QB streaming
D.Metcalf,1,1,1000,0.0125,0.0129,Watch,Boom-bust WR
B.Bowers,1,1,1000,0.0125,0.0130,Keep,Rookie TE star
M.Andrews,1,1,800,0.0125,0.0126,Watch,Injury concerns
P.Nacua,1,2,2000,0.0125,0.0141,Keep,Breakout star - Batch 2
C.Brown,1,2,2000,0.0125,0.0137,Watch,High ceiling WR
K.Shakir,1,2,2000,0.0125,0.0134,Watch,Slot specialist
J.Dobbins,1,2,1500,0.0125,0.0131,Watch,Injury return
T.Henderson,1,2,1500,0.0125,0.0130,Watch,Chargers RB1
D.Henry,1,2,1000,0.0125,0.0132,Watch,King Henry
T.Warren,1,2,1000,0.0125,0.0128,Watch,Eagles RBBC
E.Egbuka,1,2,1000,0.0125,0.0129,Watch,OSU standout
J.Smith-Njigba,1,2,1000,0.0125,0.0127,Watch,SEA WR2
D.Maye,1,2,1000,0.0125,0.0126,Watch,Rookie QB
A.Kamara,1,2,1000,0.0125,0.0133,Watch,Saints workhorse
G.Kittle,1,2,1000,0.0125,0.0131,Keep,Elite blocker + receiver
Z.Flowers,1,2,1200,0.0125,0.0130,Watch,RAV WR1
J.Mixon,1,2,900,0.0125,0.0128,Watch,HOU RB featured
R.White,1,2,1100,0.0125,0.0129,Watch,TB top target
T.Etienne,1,2,1000,0.0125,0.0127,Watch,JAX backfield
X.Worthy,1,2,800,0.0125,0.0126,Watch,KC speed weapon
M.Harrison,1,2,1500,0.0125,0.0135,Keep,ARI rookie WR - high upside
B.Hall,1,2,1000,0.0125,0.0128,Watch,NYJ featured back
A.Cooper,1,2,800,0.0125,0.0126,Watch,Veteran WR
D.London,1,2,1000,0.0125,0.0129,Watch,ATL alpha WR
J.Burrow,1,3,1200,0.0125,0.0140,Keep,Elite QB - Batch 3
L.Jackson,1,3,1500,0.0125,0.0142,Keep,MVP candidate
J.Allen,1,3,1800,0.0125,0.0144,Keep,Dual threat QB
C.Stroud,1,3,1400,0.0125,0.0138,Keep,Sophomore breakout
J.Hurts,1,3,1600,0.0125,0.0141,Keep,Rushing upside QB
D.Prescott,1,3,1000,0.0125,0.0132,Watch,DAL franchise QB
J.Goff,1,3,900,0.0125,0.0129,Watch,DET efficient QB
T.Tagovailoa,1,3,1100,0.0125,0.0134,Watch,MIA system QB
B.Purdy,1,3,1000,0.0125,0.0131,Watch,SF game manager
A.Richardson,1,3,800,0.0125,0.0127,Watch,IND rushing QB
K.Williams,1,3,1000,0.0125,0.0130,Watch,Rookie QB development
J.Daniels,1,3,1200,0.0125,0.0136,Keep,WAS rookie sensation
S.Darnold,1,3,700,0.0125,0.0126,Watch,MIN backup value
K.Cousins,1,3,800,0.0125,0.0128,Watch,ATL veteran QB
M.Stafford,1,3,600,0.0125,0.0125,Watch,LAR aging QB
T.Lawrence,1,3,900,0.0125,0.0129,Watch,JAX franchise hopes`;

function parseCSV(csv: string): Player[] {
  const lines = csv.trim().split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    const values = line.split(',');
    const player: any = {};
    
    headers.forEach((header, index) => {
      const value = values[index];
      if (header === 'pack_batch' || header === 'release_batch' || header === 'shares_owned') {
        player[header] = parseInt(value) || 0;
      } else if (header === 'avg_cost' || header === 'latest_price') {
        player[header] = parseFloat(value) || 0;
      } else {
        player[header] = value || '';
      }
    });
    
    return player as Player;
  });
}

function computeDerivedFields(player: Player): PlayerDerived {
  const is_owned = player.shares_owned > 0;
  const unrealised_value = player.shares_owned * player.latest_price;
  const avg_cost_value = player.shares_owned * player.avg_cost;
  const unrealised_pnl = unrealised_value - avg_cost_value;
  
  return {
    ...player,
    is_owned,
    unrealised_value,
    avg_cost_value,
    unrealised_pnl,
  };
}

export const usePortfolioStore = create<PortfolioState>((set, get) => ({
  players: parseCSV(INITIAL_PLAYERS_CSV),
  trades: [
    {
      date: '2025-11-11',
      player: 'P.Mahomes',
      action: 'Buy',
      shares: 1270.35,
      price: 0.161,
      fees: 6.15,
      notes: 'Initial position',
      gross: 204.53,
      net: 198.38,
      realised_pnl: 0,
    },
    {
      date: '2025-11-11',
      player: 'P.Mahomes',
      action: 'Buy',
      shares: 30.11,
      price: 0.133,
      fees: 0.12,
      notes: 'Small add',
      gross: 4.00,
      net: 3.88,
      realised_pnl: 0,
    },
    {
      date: '2025-11-11',
      player: 'P.Mahomes',
      action: 'Buy',
      shares: 708.49,
      price: 0.109,
      fees: 2.31,
      notes: 'Averaging down',
      gross: 77.23,
      net: 74.92,
      realised_pnl: 0,
    },
    {
      date: '2025-11-11',
      player: 'P.Mahomes',
      action: 'Buy',
      shares: 941.5,
      price: 0.0963,
      fees: 2.72,
      notes: 'DCA - Evening accumulation',
      gross: 90.67,
      net: 87.95,
      realised_pnl: 0,
    },
    {
      date: '2025-11-11',
      player: 'GOLD',
      action: 'Buy',
      shares: 0,
      price: 0,
      fees: 0,
      notes: 'Transfer In',
      gross: 79.96,
      net: 79.96,
      realised_pnl: 0,
    },
    {
      date: '2025-11-12',
      player: 'B.Robinson',
      action: 'Buy',
      shares: 500,
      price: 0.0583,
      fees: 0.87,
      notes: 'Morning add - value opportunity',
      gross: 29.15,
      net: 28.28,
      realised_pnl: 0,
    },
    {
      date: '2025-11-12',
      player: 'A.St. Brown',
      action: 'Buy',
      shares: 500,
      price: 0.0569,
      fees: 0.85,
      notes: 'Morning add - consistent performer',
      gross: 28.45,
      net: 27.60,
      realised_pnl: 0,
    },
    {
      date: '2025-11-12',
      player: 'T.Kelce',
      action: 'Buy',
      shares: 500,
      price: 0.0221,
      fees: 0.33,
      notes: 'Morning add - TE value',
      gross: 11.05,
      net: 10.72,
      realised_pnl: 0,
    },
  ],
  settings: {
    base_currency: 'USD',
    deposit_total: 1000,
    withdrawn_total: 0,
    cash_balance: 8.37,
    fees_paid: 13.35,
  },
  
  isLoading: false,
  lastRefreshed: null,
  
  showOnlyOwned: true,
  releaseBatchFilter: 'All',
  statusFilter: 'All',
  searchQuery: '',
  hideZeroShares: true,
  
  setShowOnlyOwned: (value) => set({ showOnlyOwned: value }),
  setReleaseBatchFilter: (value) => set({ releaseBatchFilter: value }),
  setStatusFilter: (value) => set({ statusFilter: value }),
  setSearchQuery: (value) => set({ searchQuery: value }),
  setHideZeroShares: (value) => set({ hideZeroShares: value }),
  
  refreshFromSupabase: async () => {
    set({ isLoading: true });
    try {
      const [snapshot, totals] = await Promise.all([
        fetchPortfolioSnapshot(),
        fetchPortfolioTotals(),
      ]);
      
      // Map Supabase data to Player format
      const players: Player[] = snapshot.map(item => ({
        name: item.display_name,
        pack_batch: item.pack_batch || 1,
        release_batch: item.release_batch || 1,
        shares_owned: item.shares || 0,
        avg_cost: item.avg_cost || 0,
        latest_price: item.price_usd || 0,
        status_tag: item.label === 'KEEP' ? 'Keep' : item.label === 'SELL' ? 'Sell' : 'Watch',
        notes: '',
      }));
      
      // Map Supabase totals to settings format
      const settings: PortfolioSettings = {
        base_currency: 'USD',
        deposit_total: totals?.total_deposited || 1000,
        withdrawn_total: 0,
        cash_balance: totals?.net_cash || 0,
        fees_paid: totals?.total_fees || 0,
      };
      
      console.log('✅ Supabase data refreshed:', {
        players: players.length,
        totalValue: totals?.holdings_value,
        cash: totals?.net_cash,
      });
      
      set({
        players,
        settings,
        lastRefreshed: new Date(),
      });
    } catch (error) {
      console.error('Failed to refresh from Supabase:', error);
    } finally {
      set({ isLoading: false });
    }
  },
  
  addTrade: (trade) => {
    const state = get();
    const player = state.players.find(p => p.name === trade.player);
    
    if (!player) return;
    
    const gross = trade.shares * trade.price;
    const net = gross - trade.fees;
    let realised_pnl = 0;
    
    if (trade.action === 'Buy') {
      // Weighted average cost
      const totalShares = player.shares_owned + trade.shares;
      const totalCost = (player.shares_owned * player.avg_cost) + (trade.shares * trade.price);
      const newAvgCost = totalShares > 0 ? totalCost / totalShares : player.avg_cost;
      
      set({
        players: state.players.map(p =>
          p.name === trade.player
            ? { ...p, shares_owned: totalShares, avg_cost: newAvgCost }
            : p
        ),
        trades: [...state.trades, { ...trade, gross, net, realised_pnl }],
      });
    } else if (trade.action === 'Sell') {
      // Calculate realised PnL
      realised_pnl = (trade.price - player.avg_cost) * trade.shares - trade.fees;
      const newShares = Math.max(0, player.shares_owned - trade.shares);
      
      set({
        players: state.players.map(p =>
          p.name === trade.player
            ? { ...p, shares_owned: newShares }
            : p
        ),
        trades: [...state.trades, { ...trade, gross, net, realised_pnl }],
      });
    }
  },
  
  updatePlayer: (name, updates) => {
    set({
      players: get().players.map(p =>
        p.name === name ? { ...p, ...updates } : p
      ),
    });
  },
  
  importPlayers: (csvData) => {
    set({ players: parseCSV(csvData) });
  },
  
  resetShares: () => {
    set({
      players: get().players.map(p => ({ ...p, shares_owned: 0, avg_cost: 0 })),
    });
  },
  
  updateSettings: (settings) => {
    set({ settings: { ...get().settings, ...settings } });
  },
  
  getFilteredPlayers: () => {
    const state = get();
    let filtered = state.players;
    
    // Apply filters
    if (state.showOnlyOwned) {
      filtered = filtered.filter(p => p.shares_owned > 0);
    }
    
    if (state.hideZeroShares) {
      filtered = filtered.filter(p => p.shares_owned > 0);
    }
    
    if (state.releaseBatchFilter !== 'All') {
      filtered = filtered.filter(p => p.release_batch === state.releaseBatchFilter);
    }
    
    if (state.statusFilter !== 'All') {
      filtered = filtered.filter(p => p.status_tag === state.statusFilter);
    }
    
    if (state.searchQuery) {
      const query = state.searchQuery.toLowerCase();
      filtered = filtered.filter(p => p.name.toLowerCase().includes(query));
    }
    
    return filtered.map(computeDerivedFields);
  },
  
  getOwnedPlayers: () => {
    return get().players
      .filter(p => p.shares_owned > 0)
      .map(computeDerivedFields);
  },
  
  getTotalUnrealisedValue: () => {
    return get().getOwnedPlayers().reduce((sum, p) => sum + p.unrealised_value, 0);
  },
  
  getTotalUnrealisedPnL: () => {
    return get().getOwnedPlayers().reduce((sum, p) => sum + p.unrealised_pnl, 0);
  },
  
  getTotalRealisedPnL: () => {
    return get().trades.reduce((sum, t) => sum + (t.realised_pnl || 0), 0);
  },
  
  getTotalPortfolioValue: () => {
    return get().getTotalUnrealisedValue() + get().settings.cash_balance;
  },
}));