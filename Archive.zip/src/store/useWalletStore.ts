/**
 * Simple Wallet Store
 * 
 * Just stores wallet address and portfolio data
 * No Web3 connection - data comes from API calls
 */

import { create } from 'zustand';

export interface WalletState {
  // Wallet
  walletAddress: string;
  
  // Data (from API)
  tokenBalances: any[];
  transactions: any[];
  duneData: any;
  
  // Loading states
  isFetching: boolean;
  lastFetched: Date | null;
  
  // Actions
  setWalletAddress: (address: string) => void;
  setData: (data: { tokenBalances?: any[]; transactions?: any[]; duneData?: any }) => void;
  refreshData: () => Promise<void>;
}

export const useWalletStore = create<WalletState>((set, get) => ({
  // Initial state
  walletAddress: '0xFc1A8921eA05bEC9ceb536f8aEE02AF881D72F6B',
  tokenBalances: [],
  transactions: [],
  duneData: [],
  isFetching: false,
  lastFetched: null,

  // Set wallet address
  setWalletAddress: (address) => {
    set({ walletAddress: address });
  },

  // Set data from API
  setData: (data) => {
    set({
      tokenBalances: data.tokenBalances || get().tokenBalances,
      transactions: data.transactions || get().transactions,
      duneData: data.duneData || get().duneData,
      lastFetched: new Date(),
    });
  },

  // Refresh data (calls API)
  refreshData: async () => {
    const state = get();
    if (!state.walletAddress) return;

    set({ isFetching: true });
    
    try {
      const { fetchMyPortfolio } = await import('../lib/blockchainData');
      const portfolioData = await fetchMyPortfolio(state.walletAddress);
      
      set({
        tokenBalances: portfolioData.tokenBalances,
        transactions: portfolioData.transactions,
        duneData: portfolioData.duneData,
        lastFetched: new Date(),
        isFetching: false,
      });
    } catch (error) {
      console.error('Error refreshing data:', error);
      set({ isFetching: false });
    }
  },
}));
